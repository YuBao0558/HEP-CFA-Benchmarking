# HEP-CFA Benchmarking Code

Analysis code for:

**"Benchmarking Classification and Removal Decisions for QRS-Peak Cardiac Field Artifacts in Heartbeat-Evoked Potential Analysis: A Cross-Dataset Multiverse Study"**

Bao, Y., Liu, X., Li, B., Zhang, Y., Lu, S., Lu, M., Jiang, L., Cai, W., Wang, Y., Li, H., & Chen, L.

---

## Overview

This repository contains the code used to (1) characterize the R-peak-locked energy
enrichment ratio (ER) of independent components, (2) test for a bimodal structure in the
CFA ER distribution, (3) evaluate threshold sensitivity, and (4) benchmark the effect of
QRS-peak CFA retention/removal on heartbeat-evoked potential (HEP) estimation through a
1,296-specification multiverse analysis.

The analyses use three public datasets:

| Dataset | Source | DOI |
|---|---|---|
| BBBD | Madsen et al. (2026), *Scientific Data* | 10.1038/s41597-026-07215-1 |
| SENSE-42 | Zhang et al. (2025), *Zenodo* | 10.5281/zenodo.20328099 |
| ds003816 | Sun, Wong & Gao (2021), *OpenNeuro* | 10.18112/openneuro.ds003816.v1.0.0 |

Raw data are **not** included in this repository and must be obtained from the original
sources above under their respective licensing terms.

---

## Repository layout

```
pipeline/          Core preprocessing, ICA, CFA, and multiverse pipeline (00-09)
  METHODS_pipeline.md   Frozen parameter overview and methodological rationale
  common.py             Shared paths and constants
  preprocess_utils.py   EEG preprocessing utilities
  00_inventory.py       Data inventory and quality audit
  01_rpeak_validation.py  R-peak re-validation (official vs. self-check)
  02_preprocess.py      EEG preprocessing (clean/eye-only dual track)
  03b_hep_dual.py       HEP extraction (ROI x window, mean/RMS)
  03c_pseudotrial.py    Pseudotrial drift correction
  03d_singletrial.py    Single-trial HEP export (RR / respiration covariates)
  03e_topography.py     Scalp topography export
  04_surrogate_l1.py    Level-1 surrogate null distributions
  05_coupling_l2.py     Level-2 heartbeat-locked phase consistency (ITPC)
  06_multiverse.py      Multiverse analysis (1,296 pipelines)
  06b_cfa_threshold_scan.py  CFA threshold sensitivity scan
  06c_energy_ratio_only.py   CFA energy-ratio distribution export
  06d_cfa_distribution_test.py  CFA distribution tests (dip test)
  07_lmm.R              LMM main models, moderation, equivalence (TOST)
  08_epoch_reject_abs_effect.py  Epoch-rejection absolute-effect analysis
  08_hrv.py             Heart-rate variability (time + frequency)
  09_cross_dataset.py   Cross-dataset effect-size summary
  09_cross_dataset_consistency.py  Cross-dataset consistency checks
  supp_common_epoch.py  Shared epoch utilities for supplementary analyses
  supp_icalabel_validation.py  ICLabel validation
  run_one_experiment.sh  Run the pipeline for a single experiment
  run_all_pipeline.sh / run_all_resumable.sh  Full run (resumable)
analysis/code/      Meta-analyses, robustness, and figure-generation scripts
  plot/             Figure scripts (Fig. 1-5, Fig. S1-S4)
```

---

## Requirements

Python (>= 3.9) with the following packages:

- `mne` (EEG preprocessing and ICA)
- `mne_icalabel` (ICLabel component annotation)
- `numpy`, `scipy`
- `neurokit2` (R-peak detection for validation)

R (>= 4.2) with `lme4`, `lmerTest`, `dplyr`, `tidyr`.

Install the Python dependencies with:

```bash
pip install mne mne_icalabel numpy scipy neurokit2
```

---

## Reproducing the analysis

1. Download the datasets from the sources listed above and set the paths in
   `pipeline/common.py` (`ROOT`, `EXP2`-`EXP5`, `PROC`, `OUT`).

2. Run the pipeline per experiment:

   ```bash
   cd pipeline
   BBBD_EXPERIMENT=2 ./run_one_experiment.sh
   ```

   or run the full resumable pipeline with `./run_all_resumable.sh`.

3. Cross-dataset and figure scripts are under `analysis/code/` and
   `analysis/code/plot/`.

Frozen parameter values and the methodological rationale for each step are documented
in `pipeline/METHODS_pipeline.md`.

---

## License

This code is licensed under the Creative Commons Attribution 4.0 International
License (CC-BY-4.0). See `LICENSE`. The datasets remain subject to their original
licensing terms.
